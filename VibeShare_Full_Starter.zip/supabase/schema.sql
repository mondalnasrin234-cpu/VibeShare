create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default 'VibeShare User',
  bio text default '',
  avatar_url text,
  followers_count integer not null default 0,
  following_count integer not null default 0,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text not null default '',
  media_url text,
  media_type text not null default 'status' check(media_type in ('status','photo','video')),
  visibility text not null default 'public' check(visibility in ('public','followers','private')),
  view_count bigint not null default 0,
  like_count bigint not null default 0,
  comment_count bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,post_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check(follower_id <> following_id)
);

create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  balance numeric(12,2) not null default 0,
  lifetime_earned numeric(12,2) not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  entry_type text not null check(entry_type in ('ad_revenue','creator_share','viewer_reward','bonus','withdrawal','adjustment')),
  amount numeric(12,2) not null,
  reference_id text,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  amount numeric(12,2) not null check(amount > 0),
  status text not null default 'pending' check(status in ('pending','approved','rejected','paid')),
  payout_method text,
  payout_reference text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  reason text not null,
  status text not null default 'open' check(status in ('open','reviewed','resolved')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles(id,username,display_name)
  values (
    new.id,
    lower(regexp_replace(coalesce(new.raw_user_meta_data->>'display_name','user') || '_' || substr(new.id::text,1,6),'[^a-zA-Z0-9_]','','g')),
    coalesce(new.raw_user_meta_data->>'display_name','VibeShare User')
  )
  on conflict (id) do nothing;
  insert into public.wallets(user_id) values(new.id) on conflict do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.reports enable row level security;

create policy "profiles public read" on public.profiles for select using (true);
create policy "profiles own update" on public.profiles for update using (auth.uid()=id);

create policy "posts public read" on public.posts for select using (visibility='public' or auth.uid()=user_id);
create policy "posts own insert" on public.posts for insert with check(auth.uid()=user_id);
create policy "posts own update" on public.posts for update using(auth.uid()=user_id);
create policy "posts own delete" on public.posts for delete using(auth.uid()=user_id);

create policy "likes public read" on public.likes for select using(true);
create policy "likes own insert" on public.likes for insert with check(auth.uid()=user_id);
create policy "likes own delete" on public.likes for delete using(auth.uid()=user_id);

create policy "comments public read" on public.comments for select using(true);
create policy "comments own insert" on public.comments for insert with check(auth.uid()=user_id);
create policy "comments own delete" on public.comments for delete using(auth.uid()=user_id);

create policy "follows public read" on public.follows for select using(true);
create policy "follows own insert" on public.follows for insert with check(auth.uid()=follower_id);
create policy "follows own delete" on public.follows for delete using(auth.uid()=follower_id);

create policy "wallet own read" on public.wallets for select using(auth.uid()=user_id);
create policy "ledger own read" on public.wallet_ledger for select using(auth.uid()=user_id);
create policy "withdraw own read" on public.withdrawal_requests for select using(auth.uid()=user_id);
create policy "withdraw own insert" on public.withdrawal_requests for insert with check(auth.uid()=user_id);
create policy "reports own insert" on public.reports for insert with check(auth.uid()=reporter_id);

insert into storage.buckets(id,name,public) values('media','media',true) on conflict(id) do nothing;
insert into storage.buckets(id,name,public) values('avatars','avatars',true) on conflict(id) do nothing;

create policy "media public read" on storage.objects for select using(bucket_id='media');
create policy "media own upload" on storage.objects for insert with check(bucket_id='media' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "media own delete" on storage.objects for delete using(bucket_id='media' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "avatars public read" on storage.objects for select using(bucket_id='avatars');
create policy "avatars own upload" on storage.objects for insert with check(bucket_id='avatars' and auth.uid()::text = (storage.foldername(name))[1]);
