
# VibeShare — Full Starter

A production-oriented foundation for a social video/photo platform:
Create • Watch • Share • Earn

## Stack
- Web: Next.js + TypeScript
- Auth/DB/Storage: Supabase
- Mobile: Flutter
- Ads: Google AdSense (web) / Google Mobile Ads (mobile)
- Video/photo storage: Supabase Storage initially; move large video delivery to a dedicated CDN when traffic grows.

## Included
- Email/password authentication
- User profiles
- Photo/video/status post creation
- Feed
- Reels page
- Wallet
- Withdrawal requests
- Admin dashboard starter
- Supabase SQL schema + RLS policies
- Basic earnings ledger
- Report table
- Flutter mobile starter with Supabase auth and Google Mobile Ads dependency

## 1. Create Supabase
Create a project at https://supabase.com and run `supabase/schema.sql` in SQL Editor.
Create Storage buckets named:
- media (public for MVP, or private + signed URLs for production)
- avatars (public for MVP)

Copy your project URL and anon key.

## 2. Web
cd web
copy .env.example .env.local
npm install
npm run dev

Set:
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...

Open http://localhost:3000

## 3. Admin
The SQL schema includes an is_admin flag in profiles.
For your own account, set:
update public.profiles set is_admin=true where id='YOUR_USER_UUID';

Then visit /admin.

## 4. Flutter
cd mobile
flutter pub get
flutter run

Edit lib/main.dart and set the same Supabase URL/key.
For real Android ads, create an AdMob app and replace the test ad unit IDs before release.

## 5. Earnings reality
The app can calculate an internal ledger, but it cannot magically create advertising revenue.
You need approved ad accounts, real ad impressions/revenue, fraud controls, tax/KYC handling and a payout provider.
Never promise users a fixed earning amount.

## 6. Production checklist
- Use private video storage + signed URLs for sensitive content.
- Add transcoding (HLS/DASH) and CDN.
- Add moderation and copyright/takedown workflow.
- Add rate limits, bot detection and device/IP abuse controls.
- Add email/phone verification and account recovery.
- Add creator eligibility rules and a minimum payout threshold.
- Connect a compliant payout provider and KYC.
- Connect AdSense/AdMob only after account approval.
- Add backups, monitoring, logging and error tracking.
- Obtain legal terms, privacy policy, community guidelines and copyright policy for your jurisdiction.
