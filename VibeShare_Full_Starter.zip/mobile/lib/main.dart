import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

const supabaseUrl = 'https://YOUR_PROJECT.supabase.co';
const supabaseAnonKey = 'YOUR_ANON_KEY';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  await MobileAds.instance.initialize();
  runApp(const VibeShareApp());
}

class VibeShareApp extends StatelessWidget {
  const VibeShareApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'VibeShare',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.deepPurple),useMaterial3:true),
    home:const Home());
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home> {
  int index=0;
  final pages=const [Feed(), Reels(), Create(), Wallet(), Profile()];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('VibeShare',style:TextStyle(fontWeight:FontWeight.w800))),
    body:pages[index],
    bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),
        NavigationDestination(icon:Icon(Icons.video_library_outlined),label:'Reels'),
        NavigationDestination(icon:Icon(Icons.add_circle_outline),label:'Create'),
        NavigationDestination(icon:Icon(Icons.account_balance_wallet_outlined),label:'Wallet'),
        NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile'),
      ]));
}

class Feed extends StatelessWidget { const Feed({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
  Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:const Text('Create Post'),subtitle:const Text("What's on your mind?"),trailing:IconButton(icon:const Icon(Icons.add_box),onPressed:()=>{}))),
  const DemoPost(name:'Riya Das',caption:'Beautiful day 🌅 #nature',icon:Icons.image),
  const DemoPost(name:'Sohan Khan',caption:'Travel vibes ❤️',icon:Icons.play_circle)
]); }

class DemoPost extends StatelessWidget { final String name,caption; final IconData icon; const DemoPost({super.key,required this.name,required this.caption,required this.icon});
@override Widget build(BuildContext c)=>Card(margin:const EdgeInsets.only(bottom:12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
ListTile(leading:CircleAvatar(child:Text(name[0])),title:Text(name),subtitle:const Text('Just now')),
Container(height:260,width:double.infinity,color:Colors.deepPurple.withOpacity(.1),child:Icon(icon,size:80,color:Colors.deepPurple)),
Padding(padding:const EdgeInsets.all(14),child:Text(caption)),
const Padding(padding:EdgeInsets.fromLTRB(14,0,14,14),child:Text('❤️ Like     💬 Comment     ↗ Share'))
])); }

class Reels extends StatelessWidget { const Reels({super.key}); @override Widget build(BuildContext c)=>Container(color:Colors.black,child:const Center(child:Text('▶  VibeShare Reels',style:TextStyle(color:Colors.white,fontSize:28)))); }

class Create extends StatelessWidget { const Create({super.key}); @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(18),child:Column(children:[
const Text('Create Post',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:20),
Container(height:230,width:double.infinity,decoration:BoxDecoration(border:Border.all(color:Colors.grey),borderRadius:BorderRadius.circular(16)),child:const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.cloud_upload,size:65),Text('Choose photo/video')])),
const SizedBox(height:15),const TextField(maxLines:4,decoration:InputDecoration(border:OutlineInputBorder(),hintText:'Caption or status...')),const SizedBox(height:15),
FilledButton(onPressed:(){},child:const Text('Publish'))])); }

class Wallet extends StatelessWidget { const Wallet({super.key}); @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(18),child:Column(children:[
Container(width:double.infinity,padding:const EdgeInsets.all(24),decoration:BoxDecoration(color:Colors.deepPurple,borderRadius:BorderRadius.circular(18)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Available balance',style:TextStyle(color:Colors.white70)),Text('\$0.00',style:TextStyle(color:Colors.white,fontSize:40,fontWeight:FontWeight.bold)),Text('Real payouts require verified ad revenue and eligibility.',style:TextStyle(color:Colors.white70))])),
const SizedBox(height:15),const ListTile(leading:Icon(Icons.ads_click),title:Text('Ad revenue'),subtitle:Text('Creator share')),const ListTile(leading:Icon(Icons.stars),title:Text('Viewer rewards'),subtitle:Text('Policy-based rewards'))])); }

class Profile extends StatelessWidget { const Profile({super.key}); @override Widget build(BuildContext c)=>Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
const CircleAvatar(radius:50,child:Text('V',style:TextStyle(fontSize:40))),const SizedBox(height:14),const Text('VibeShare User',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const Text('@user'),const SizedBox(height:15),const Text('Posts     Followers     Following') ])); }
