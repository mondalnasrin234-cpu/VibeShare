import "./globals.css";

export const metadata = {
  title: "VibeShare",
  description: "Create • Watch • Share • Earn"
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}