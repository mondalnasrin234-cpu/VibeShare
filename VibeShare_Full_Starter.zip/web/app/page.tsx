import Link from "next/link";
import { supabaseBrowser } from "../lib/supabase";

export default async function Home() {
  const sb = supabaseBrowser();
  const {data:posts} = await sb.from("posts").select("id,caption,media_url,media_type,created_at,profiles(display_name,username,avatar_url)").eq("visibility","public").order("created_at",{ascending:false}).limit(20);

  return <><header className="top"><div className="brand">▶ <span>Vibe</span>Share</div><nav className="nav"><Link href="/">Home</Link><Link href="/reels">Reels</Link><Link href="/upload">Create</Link><Link href="/wallet">Wallet</Link><Link href="/profile">Profile</Link><Link href="/admin">Admin</Link><Link href="/login">Login</Link></nav></header>
  <main className="page"><section className="hero"><div><h1>Create • Watch • Share • Earn</h1><p>ভিডিও, ছবি, রিল এবং স্ট্যাটাস—এক প্ল্যাটফর্মে।</p><Link className="btn light" href="/signup">Create account</Link></div><div className="card" style={{background:"#ffffff12",color:"white"}}>🚀 VibeShare<br/><span className="muted">Creator community MVP</span></div></section>
  <div className="grid"><section>{(posts||[]).map((p:any)=><article className="card post" key={p.id}><div className="posthead"><div className="avatar">{(p.profiles?.display_name||"V")[0]}</div><div><b>{p.profiles?.display_name||"VibeShare user"}</b><div className="muted">@{p.profiles?.username||"user"}</div></div></div><p>{p.caption}</p>{p.media_url&&(p.media_type==="video"?<video controls src={p.media_url}/>:<img src={p.media_url} alt="post"/>) }<div className="actions">❤️ Like &nbsp; 💬 Comment &nbsp; ↗ Share</div></article>)}
  {!posts?.length&&<div className="card"><h2>No posts yet</h2><p>Be the first creator. Create an account and upload a post.</p></div>}</section>
  <aside><div className="card"><h3>Trending</h3><p>#nature</p><p>#travel</p><p>#funny</p><p>#music</p></div><div className="card"><h3>How earnings work</h3><p>Eligible creators can receive a share of verified platform revenue.</p><p>Viewer rewards can be enabled by your earning policy.</p></div></aside></div></main></>;
}